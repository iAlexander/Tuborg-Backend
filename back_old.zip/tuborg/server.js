const Logger = require('./src/Logger')

const helmet = require('helmet');
const express = require('express');
const cors = require('cors');
const http = require('http');

class Server {

    constructor() {
        this._express = express;
        this.app = express();
    }

    init() {
        // set up session cookies

        this.app.use((req, res, next) => {
            res.set('X-Powered-By', 'PHP/7.1.2-1+b1');
            next();
        });
        this.app.use(express.json());
        this.app.use(express.urlencoded({extended: false}));

        this.app.use('/', express.static(process.cwd() + "/views"));
        // this.app.use(cors());

       const routeM = require('./src/route');
       new routeM(this)
        this.port = process.env.PORT || 9990;
        this.server = http.createServer(this.app);
        this.server.listen(this.port, async () => {
            // console.log(`serve listener ${ this.port}`);
            Logger.info(`serve listener ${this.port}`);
        });
    }
}

new Server().init();

