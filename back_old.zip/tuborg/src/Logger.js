class Logger {
    static log(args) {
        console.log(args);
    }

    static error(args) {
        console.error(args);
    }

    static info(args) {
        console.info(args);
    }
}
module.exports = Logger;
