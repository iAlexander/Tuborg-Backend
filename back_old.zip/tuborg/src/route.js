const Logic = require('./logic')

class Route {

    constructor(server) {
        const logic = new Logic();
        const route = server._express.Router();
        route.get('/qq', (req, res, next) => {
            console.log('aaaaa')
            res.send('hello')
        });
        route.get('/getPartyInfo/:id', logic.getPartyInfo.bind(logic));
        route.get('/getTexts', logic.getTexts.bind(logic));
        route.get('/taskDone/:id', logic.taskDone.bind(logic));


        route.post('/modifyTexts', logic.modifyTexts.bind(logic));
        route.post('/addUser', logic.addUser.bind(logic));
        route.post('/changeTaskId', logic.changeTaskId.bind(logic));
        route.post('/resetRoom', logic.resetRoom.bind(logic));

        server.app.use(route);
    }
}

module.exports = Route;
