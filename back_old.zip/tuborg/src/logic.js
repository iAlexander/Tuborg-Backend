const Logger = require('./Logger')
const RoomInfo = require('./roomInfo')
const axios = require('axios');

const defText = {
    't-1': 'The game has not started',
    't-2': 'The game is over',
};

class Logic {
    constructor() {
        this.name = 'Logic'
        this.tasks = {...defText}

        this.rooms = {
            1: new RoomInfo(1),
            2: new RoomInfo(2),
            3: new RoomInfo(3),
            4: new RoomInfo(4),
            5: new RoomInfo(5),
        }
    }

    getPartyInfo(req, res, next) {
        const id = req.params.id;
        if (this.rooms[id]) {
            const room = this.rooms[id];
            return res.json({
                ...room,
                taskText: this.tasks[room.currentTask]
            })
        }
        res.json({
            error: "party not found"
        })
    }


    modifyTexts(req, res, next) {
        Logger.info(req.body);
        this.tasks = {...req.body, ...defText};
        Logger.info('update texts', this.tasks);
        res.json({status: 'ok'});
    }

    getTexts(req, res, next) {
        res.json(this.tasks);
    }

    addUser(req, res, next) {
        Logger.info(req.body);
        const {partyId, counter} = req.body;
        if (this.rooms[partyId]) {
            const room = this.rooms[partyId];
            room.addUser();

            if (room.isStartGame && room.lastTaskUpd === 0) {
                this.updateTaskOnCorezoid(room);
            }
            return res.json({status: 'ok'});
        }
        return res.json({status: 'fail'});
        ;
    }

    //corezoid
    changeTaskId(req, res, next) {
        Logger.info(req.body);
        const {partyId, taskId} = req.body;
        if (this.rooms[partyId]) {
            const room = this.rooms[partyId]
            room.currentTask = taskId;
            room.isRunUpdateTask = false;
            return res.json({status: 'ok'});
        }
        res.json({status: 'fail'});
    }

    //client
    taskDone(req, res, next) {
        const id = req.params.id;
        if (this.rooms[id])
            this.updateTaskOnCorezoid(this.rooms[id])
        res.send('ok');
    }

    async updateTaskOnCorezoid(room) {
        if (!room.isRunUpdateTask) {
            room.isRunUpdateTask = true
            const url = 'https://www.corezoid.com/api/1/json/public/664658/149fcfe0d7dac9497faf8095f83ed86c11e02b61';
            const data = {
                partyId: room.id
            }
            await axios.post(url, data);
        }
    }

    resetRoom(req, res, next) {
        const id = req.params.id;
        if (this.rooms[id]) {
            this.rooms[id] = new RoomInfo(id);
            return res.json({status: 'ok'});
        }
        res.json({status: 'fail'});
    }
}

module.exports = Logic;
