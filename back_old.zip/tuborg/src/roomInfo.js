class RoomInfo {

    constructor(id) {
        this.id = id;
        this.users = 0;
        this._currentTask = 't-1';
        this.previousTask = 't-1';
        this.isEndGame = false;
        this.lastTaskUpd = 0;
        this.isRunUpdateTask = false;
    }

    addUser() {
        this.users++;
    }

    get currentTask() {
        return this._currentTask;
    }

    set currentTask(id) {
        this.lastTaskUpd = Date.now();
        this.previousTask = this._currentTask;
        this._currentTask = id;
        if (this._currentTask === 't-2') {
            this.isEndGame = true
        }
    }

    get isStartGame() {
        return this.users > 4;
    }

}

module.exports = RoomInfo;
