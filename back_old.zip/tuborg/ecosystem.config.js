module.exports = {

    apps:[
        {
            name:'tuborg',
            script:"server.js",
            exec_mode: "cluster",
            instances: 2,
            watch:false,
            env: {
                "COMMON_VARIABLE": "true"
            },
            env_production:{
                NODE_ENV:"production"
            }
        }
    ]
}
