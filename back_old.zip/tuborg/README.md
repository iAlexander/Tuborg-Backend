party == room
найменування кожної комнати іде цифрою  1-5
найменування задач іде в такому порядку = 
t-1 - гра іще не розпочата і жодного завдання не було признечено
t-2 - гра завершена
t01....t(n) - ід кожної задачі.



типова відповідь на запит по getPartyInfo
┌─────────────────┬────────────────────┐
│     (index)     │       Values       │
├─────────────────┼────────────────────┤
│       id        │         1          │  //ід комнати
│      users      │         6          │  //кількість людей які приймають участь в грі
│  _currentTask   │       't-2'        │  //активна задача
│  previousTask   │       't-1'        │  //попередня задача
│    isEndGame    │        true        │  //чи закінчена гра
│   lastTaskUpd   │   1586601205808    │  // останнє обновлення задачі яке іде тільки від корезоїда
│ isRunUpdateTask │       false        │  // чи відбувається зараз запит на корезоїд по обновленню задачі (у випадку коли від кліента прийшов івент на taskDone)
│    taskText     │ 'The game is over' │  // текст активної задачі.
└─────────────────┴────────────────────┘


'/getPartyInfo/:id'  //get - отримати інформацію по грі, діючу задачу і так далі (id = номер комнати)
'/getTexts'          //get - отримати всі задачі
'/taskDone/:id'      //get - задача виконана чи пропустили
'/modifyTexts'       //post - зміна списку задач
'/addUser'           //post - добавити нового гравця
'/changeTaskId'      //post - змінити задачу (приходить тільки від корезоїду)
'/resetRoom'         //post - обнулити кімнату


Для кліента потрібно використовувати тільки 
/getPartyInfo/:id
/getTexts
/taskDone/:id


лог з тестів:
/usr/bin/node /home/taraa62/svn/d2/tuborg/node_modules/mocha/bin/_mocha --timeout 0 --ui bdd --reporter /snap/webstorm/146/plugins/NodeJS/js/mocha-intellij/lib/mochaIntellijReporter.js /home/taraa62/svn/d2/tuborg/test/text.js
Debugger listening on ws://127.0.0.1:44397/86dc8346-a398-4f86-917e-eb377a2fe3f2
For help, see: https://nodejs.org/en/docs/inspector
Debugger attached.
serve listener 9990
{
  '01': 'text1',
  '02': 'text2',
  '03': 'text3',
  '04': 'text4',
  '05': 'text5'
}
update texts
{ partyId: '1' }
{ partyId: '1' }
{ partyId: '1' }
{ partyId: '1' }
{ partyId: '1' }
{ partyId: '1' }
{
  partyId: '1',
  taskId: 't09',
  sys: {
    ref: null,
    obj_id: '5e919cf582ba9621a11fe814',
    conv_id: 664658,
    node_id: '5e906349513aa06451164f81'
  }
}
{
  partyId: '1',
  taskId: 't-2',
  sys: {
    ref: null,
    obj_id: '5e919cf582ba9621a11fe816',
    conv_id: 664658,
    node_id: '5e906349513aa06451164f81'
  }
}
current task = t-2
┌─────────────────┬────────────────────┐
│     (index)     │       Values       │
├─────────────────┼────────────────────┤
│       id        │         1          │
│      users      │         6          │
│  _currentTask   │       't-2'        │
│    isEndGame    │        true        │
│   lastTaskUpd   │   1586601205808    │
│ isRunUpdateTask │       false        │
│    taskText     │ 'The game is over' │
└─────────────────┴────────────────────┘
{
  partyId: '1',
  taskId: 't00',
  sys: {
    ref: null,
    obj_id: '5e919cf5513aa064512066a8',
    conv_id: 664658,
    node_id: '5e906349513aa06451164f81'
  }
}
current task = t00
{
  partyId: '1',
  taskId: 't01',
  sys: {
    ref: null,
    obj_id: '5e919cf6513aa064512066ab',
    conv_id: 664658,
    node_id: '5e906349513aa06451164f81'
  }
}
current task = t01
{
  partyId: '1',
  taskId: 't02',
  sys: {
    ref: null,
    obj_id: '5e919cf6513aa064512066ac',
    conv_id: 664658,
    node_id: '5e906349513aa06451164f81'
  }
}
current task = t02
{
  partyId: '1',
  taskId: 't03',
  sys: {
    ref: null,
    obj_id: '5e919cf682ba9621a11fe81e',
    conv_id: 664658,
    node_id: '5e906349513aa06451164f81'
  }
}
current task = t03
{
  partyId: '1',
  taskId: 't04',
  sys: {
    ref: null,
    obj_id: '5e919cf782ba9621a11fe821',
    conv_id: 664658,
    node_id: '5e906349513aa06451164f81'
  }
}
current task = t04
{
  partyId: '1',
  taskId: 't05',
  sys: {
    ref: null,
    obj_id: '5e919cf7513aa064512066b3',
    conv_id: 664658,
    node_id: '5e906349513aa06451164f81'
  }
}
current task = t05
{
  partyId: '1',
  taskId: 't06',
  sys: {
    ref: null,
    obj_id: '5e919cf7513aa064512066b7',
    conv_id: 664658,
    node_id: '5e906349513aa06451164f81'
  }
}
current task = t06
{
  partyId: '1',
  taskId: 't07',
  sys: {
    ref: null,
    obj_id: '5e919cf7513aa064512066ba',
    conv_id: 664658,
    node_id: '5e906349513aa06451164f81'
  }
}
current task = t07
{
  partyId: '1',
  taskId: 't08',
  sys: {
    ref: null,
    obj_id: '5e919cf882ba9621a11fe82b',
    conv_id: 664658,
    node_id: '5e906349513aa06451164f81'
  }
}
current task = t08
t08
