2020-04-30 16:18:25,848 INFO - tech:info: TECH USER INFO => getBalance!!!!
    2020-04-30 16:18:25,848 INFO - tech:info: TECH USER INFO => getBalance = > 319000
2020-04-30 16:18:25,849 INFO - tech:info: =============================TECH GAME ENGINE logGameActivity:IQQRC8h93k5tdKtwW3lP8wpVEUV7pTem payload:{"command":"bet","balance":314000,"totalBet":5000,"roundResult":{"winLines":[],"totalPaid":0,"roundWin":0,"combination":[[8,4,9],[3,7,2],[2,6,1],[8,6,3],[9,3,7]]},"status":"ok"}
2020-04-30 16:18:25,969 INFO - tech:info: TECH USER INFO => getBalance!!!!
    2020-04-30 16:18:25,969 INFO - tech:info: TECH USER INFO => getBalance = > 165696
2020-04-30 16:18:26,634 INFO - tech:info: =============================TECH GAME ENGINE logGameActivity:Gg8sWrTF8LFiRfzXzQl5PR61KbKQMmbZ payload:{"command":"bet","balance":164696,"totalBet":1000,"roundResult":{"winLines":[],"totalPaid":0,"roundWin":0,"combination":[[9,3,7],[2,8,4],[0,6,2],[10,5,6],[7,1,3]]},"status":"ok"}
2020-04-30 16:18:26,779 INFO - tech:info: TECH USER INFO => getBalance!!!!
    2020-04-30 16:18:26,779 INFO - tech:info: TECH USER INFO => getBalance = > 45478
2020-04-30 16:18:27,415 INFO - tech:info: =============================TECH GAME ENGINE logGameActivity:RHLGuv2Qxi1AE0IzbdhGwbJSTpTHIIhV payload:{"command":"bet","balance":44478,"totalBet":1000,"roundResult":{"winLines":[],"totalPaid":0,"roundWin":0,"combination":[[7,8,3],[5,6,1],[8,2,6],[11,7,4],[0,8,5]]},"status":"ok"}
2020-04-30 16:18:27,473 INFO - tech:info: TECH USER INFO => getBalance!!!!
    2020-04-30 16:18:27,473 INFO - tech:info: TECH USER INFO => getBalance = > 105286
2020-04-30 16:18:27,791 INFO - tech:info: TECH USER INFO => getBalance!!!!
    2020-04-30 16:18:27,791 INFO - tech:info: TECH USER INFO => getBalance = > 837
2020-04-30 16:18:27,791 INFO - tech:info: TECH USER INFO => getBalance!!!!
    2020-04-30 16:18:27,791 INFO - tech:info: TECH USER INFO => getBalance = > 837
2020-04-30 16:18:28,126 INFO - tech:info: =============================TECH GAME ENGINE logGameActivity:NII5RU3sOqtGut1BVMVOHgCUFY4EjQwM payload:{"command":"bet","balance":104686,"totalBet":1000,"roundResult":{"winLines":[{"type":"line","number":10,"pos":[3,1,1,1,0],"win":400,"symbol":4}],"totalPaid":400,"roundWin":400,"combination":[[7,5,4],[4,1,6],[4,9,3],[4,8,10],[8,7,11]]},"status":"ok"}
2020-04-30 16:18:28,131 INFO - tech:info: =============================TECH GAME ENGINE logGameActivity:eLipkauPAfOzyhNXmIqeMJSUiHqRqeqs payload:{"command":"bet","status":"info","msg":"no_money","data":{"balance":837}}
2020-04-30 16:18:28,349 INFO - tech:info: TECH USER INFO => getBalance!!!!
    2020-04-30 16:18:28,349 INFO - tech:info: TECH USER INFO => getBalance = > 1418582
2020-04-30 16:18:29,006 INFO - tech:info: =============================TECH GAME ENGINE logGameActivity:YkJ8LLP8QvrlhLOasuPRsdu7JnltC10V payload:{"command":"bet","balance":1410582,"totalBet":10000,"roundResult":{"winLines":[{"type":"line","number":22,"pos":[1,1,3,0,0],"win":2000,"symbol":5}],"totalPaid":2000,"roundWin":2000,"combination":[[0,4,7],[5,6,2],[4,10,5],[9,4,8],[2,7,8]]},"status":"ok"}
2020-04-30 16:18:29,166 INFO - tech:info: TECH USER INFO => getBalance!!!!
    2020-04-30 16:18:29,166 INFO - tech:info: TECH USER INFO => getBalance = > 314000
2020-04-30 16:18:29,166 INFO - tech:info: =============================TECH GAME ENGINE logGameActivity:IQQRC8h93k5tdKtwW3lP8wpVEUV7pTem payload:{"command":"bet","balance":309000,"totalBet":5000,"roundResult":{"winLines":[],"totalPaid":0,"roundWin":0,"combination":[[9,3,6],[11,1,8],[1,4,11],[3,5,7],[4,9,0]]},"status":"ok"}
2020-04-30 16:18:29,473 INFO - tech:info: TECH USER INFO => getBalance!!!!
    2020-04-30 16:18:29,473 INFO - tech:info: TECH USER INFO => getBalance = > 165696
