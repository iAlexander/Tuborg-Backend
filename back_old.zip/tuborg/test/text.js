const {expect} = require('chai');
const axios = require('axios');
const sleep = require('util').promisify(setTimeout)

describe('Add new product', function () {

    const server = require('../server.js');
    let cTask = 't-1';

    it('get/set Text', async () => {
        let tasks = await axios.get('http://localhost:9990/getTexts')
        /*        expect(tasks.data).to.equal({
                    t: 'The game has not started',
                    tt: 'The game is over',
                })*/

        const data = {
            '01': 'text1',
            '02': 'text2',
            '03': 'text3',
            '04': 'text4',
            '05': 'text5',
        }
        await axios.post('http://localhost:9990/modifyTexts', data);

        tasks = await axios.get('http://localhost:9990/getTexts')
        expect(tasks).to.deep.equal(tasks);
    });

    it('add new user', async () => {
        const data = {
            "partyId": "1",
        }
        await axios.post('http://localhost:9990/addUser', data);

        await axios.post('http://localhost:9990/addUser', data);

        await axios.post('http://localhost:9990/addUser', data);

        const partyInfo = await axios.get('http://localhost:9990/getPartyInfo/1')
        expect(partyInfo.data.users).to.equal(3);
        expect(partyInfo.data.isEndGame).to.be.false;
    });

    it('add new user and start game', async () => {
        const data = {
            "partyId": "1",
        }
        await axios.post('http://localhost:9990/addUser', data);

        await axios.post('http://localhost:9990/addUser', data);

        await axios.post('http://localhost:9990/addUser', data);

        const partyInfo = await axios.get('http://localhost:9990/getPartyInfo/1')
        expect(partyInfo.data.users).to.equal(6);
        // expect(partyInfo.data.startGame).to.be.true;
    });

    it('start game', async () => {

        for (let t = 0; t < 10000; t++) {
            const partyInfo = await axios.get('http://localhost:9990/getPartyInfo/1')
            if (partyInfo.data._currentTask !== 't-1') {
                cTask = partyInfo.data._currentTask;
                return;
            }
        }
        console.table('ну все, ппц');
        // expect(partyInfo.data.users).to.equal(6);
        // expect(partyInfo.data.startGame).to.be.true;
    });
    it('run game to end', async () => {
        cTask = (await nextTask(cTask))._currentTask;
        cTask = (await nextTask(cTask))._currentTask;
        cTask = (await nextTask(cTask))._currentTask;
        cTask = (await nextTask(cTask))._currentTask;
        cTask = (await nextTask(cTask))._currentTask;
        cTask = (await nextTask(cTask))._currentTask;
        cTask = (await nextTask(cTask))._currentTask;
        cTask = (await nextTask(cTask))._currentTask;
        cTask = (await nextTask(cTask))._currentTask;
        cTask = (await nextTask(cTask))._currentTask;
        cTask = (await nextTask(cTask))._currentTask;
        cTask = (await nextTask(cTask))._currentTask;
        cTask = (await nextTask(cTask))._currentTask;
        cTask = (await nextTask(cTask))._currentTask;


        console.table(cTask);
        // expect(partyInfo.data.users).to.equal(6);
        // expect(partyInfo.data.startGame).to.be.true;
    });


});

const nextTask = async (currentId) => {
    await axios.get('http://localhost:9990/taskDone/1')

    for (let t = 0; t < 100; t++) {
        await sleep(100);
        const partyInfo = await axios.get('http://localhost:9990/getPartyInfo/1')
        if (partyInfo.data._currentTask !== currentId) {
            console.info('current task = '+ partyInfo.data._currentTask)
            if(partyInfo.data._currentTask === 't-2'){
                console.table(partyInfo.data);
            }
            return partyInfo.data;
        }
    }
    throw new Error('next task not found')
}
