const logger = {
    info: console.info,
    error: console.error
};

const engineId = '111'

class Platform {
    constructor(balance) {
        this.balance = balance;
    }

    getBalance(engineId) {
        return this.balance;
    }

    withdraw(engineId, bet) {
        if (this.balance >= bet) {
            this.balance -= bet;
            return true
        }
        return false;
    }

    deposit(engineId, totalPaid) {
        this.balance += totalPaid;
    }
}

let platform = null;

const getBalance = (bet, totalPaid) => {
    try {
        logger.info("TECH USER INFO => getBalance!!!!");
        let curr = platform.getBalance(engineId);
        logger.info("TECH USER INFO => getBalance = > " + curr);
        if (bet > 0) {
            if (curr < bet) return -1;
            else {
                const result = platform.withdraw(engineId, bet);
                if (!result) return -999;
                curr -= bet;
            }
        }

        if (totalPaid > 0) {
            console.log('====================')
            platform.deposit(engineId, totalPaid);
            curr += totalPaid;
        }
        return curr;
    } catch (e) {
        logger.error(e);
        throw e;
    }
}

const checkBalance = (obj) => {
    if (obj.baseParam.balance < 0) {
        if (obj.baseParam.balance > -50) {
            console.error('no_money')
        } else if (obj.baseParam.balance < -50) {
            console.error('error_server')
        }
        return false;
    }
    return true;
}

const spin = (bet, totalPaid) => {
    logger.info('spin');

    const obj = {
        baseParam: {
            balance: getBalance(bet, totalPaid)
        }
    }
    if (!checkBalance(obj)) {
        console.info('---------');
        console.info('checkBalance = false');
        console.log(JSON.stringify(obj));
        console.info('---------');
        return -1;

    }
    console.info('response true');
    console.log(JSON.stringify(obj));

    return 1
}

const test = () => {
    const testCase = [
        // [10, 100],
        // [0,0],
        // [100, 100],
        // [868, 0],
        [866, 10]
    ]



    for (let item of testCase) {
        platform = new Platform(867)
        const res = spin(...item);
        console.log('====' + res)
    }

}

test();
